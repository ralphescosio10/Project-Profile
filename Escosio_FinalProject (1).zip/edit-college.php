<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$college = null;

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $collegeId = intval($_GET['id']);

    try {
        $stmt = $db->prepare("SELECT collid, collfullname FROM colleges WHERE collid = :id");
        $stmt->bindParam(':id', $collegeId, PDO::PARAM_INT);
        $stmt->execute();
        $college = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$college) {
            echo json_encode(['success' => false, 'message' => 'College not found.']);
            exit();
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching college details: ' . $e->getMessage()]);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid college ID.']);
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $collegeName = $input['college_name'] ?? '';

    if (empty($collegeName)) {
        echo json_encode(['success' => false, 'message' => 'College name cannot be empty.']);
        exit();
    }

    if ($collegeName === $college['collfullname']) {
        echo json_encode(['success' => false, 'message' => 'No changes detected.']);
        exit();
    }

    try {
        $stmt = $db->prepare("UPDATE colleges SET collfullname = :college_name WHERE collid = :id");
        $stmt->bindParam(':college_name', $collegeName, PDO::PARAM_STR);
        $stmt->bindParam(':id', $collegeId, PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'College updated successfully!']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error updating college: ' . $e->getMessage()]);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit College</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .notification-bar {
            display: none;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .notification-bar.success {
            background-color: #013220;
            color: white;
        }

        .notification-bar.error {
            background-color: #dc3545;
            color: white;
        }

        .back-link {
            display: inline-block;
            margin-top: 10px;
            text-align: center;
            color:#013220;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form id="editCollegeForm">
        <h2>Edit College</h2>

        <div class="notification-bar" id="notificationBar"></div>

        <label for="college_name">College Name:</label>
        <input type="text" id="college_name" name="college_name" value="<?php echo htmlspecialchars($college['collfullname']); ?>" required>

        <button type="button" onclick="updateCollege()">Update College</button>
        <a href="colleges.php" class="back-link">Back to Colleges</a>
    </form>

    <script>
        function showNotification(message, type) {
            const notificationBar = document.getElementById('notificationBar');
            notificationBar.textContent = message;
            notificationBar.className = `notification-bar ${type}`;
            notificationBar.style.display = 'block';

            setTimeout(() => {
                notificationBar.style.display = 'none';
            }, 5000);
        }

        async function updateCollege() {
    const collegeName = document.getElementById('college_name').value.trim();
    const originalCollegeName = <?php echo json_encode($college['collfullname']); ?>;

    if (!collegeName) {
        showNotification('College name cannot be empty.', 'error');
        return;
    }

    if (collegeName === originalCollegeName) {
        showNotification('No changes detected.', 'error');
        return;
    }

    try {
        const response = await axios.post('', {
            college_name: collegeName
        });

        if (response.data.success) {
          
            const successMessage = encodeURIComponent(response.data.message);
            window.location.href = `colleges.php?success=${successMessage}`;
        } else {
            showNotification(response.data.message, 'error');
        }
    } catch (error) {
        console.error(error);
        showNotification('An error occurred while updating the college.', 'error');
    }
}

    </script>
</body>
</html>
