<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


$feedbackMessage = "";
$messageType = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $collegeId = $_POST['college_id'] ?? ''; 
    $collegeName = trim($_POST['college_name'] ?? '');
    $shortName = trim($_POST['short_name'] ?? '');

    if (!empty($collegeId) && !empty($collegeName) && !empty($shortName)) {
        try {
           
            $stmt = $db->prepare("SELECT COUNT(*) FROM colleges WHERE collfullname = :college_name");
            $stmt->execute(['college_name' => $collegeName]);
            $count = $stmt->fetchColumn();

            if ($count > 0) {
                $feedbackMessage = "Error: College already exists!";
                $messageType = "error";
            } else {
              
                $stmt = $db->prepare("INSERT INTO colleges (collid, collfullname, collshortname) 
                                      VALUES (:college_id, :college_name, :short_name)");
                $stmt->execute([
                    'college_id' => $collegeId,
                    'college_name' => $collegeName,
                    'short_name' => $shortName
                ]);
                $feedbackMessage = "College added successfully!";
                $messageType = "success";
            }
        } catch (PDOException $e) {
            $feedbackMessage = "Error adding college: " . $e->getMessage();
            $messageType = "error";
        }
    } else {
        $feedbackMessage = "Error: All fields are required!";
        $messageType = "error";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $collegeId = $_POST['college_id'] ?? '';

    if (!empty($collegeId)) {
        try {
            
            $stmt = $db->prepare("DELETE FROM students WHERE studcollid = :college_id");
            $stmt->execute(['college_id' => $collegeId]);

    
            $stmt = $db->prepare("DELETE FROM departments WHERE deptcollid = :college_id");
            $stmt->execute(['college_id' => $collegeId]);

       
            $stmt = $db->prepare("DELETE FROM colleges WHERE collid = :college_id");
            $stmt->execute(['college_id' => $collegeId]);

            $feedbackMessage = "College and associated departments deleted successfully!";
            $messageType = "success";
        } catch (PDOException $e) {
            $feedbackMessage = "Error deleting college: " . $e->getMessage();
            $messageType = "error";
        }
    } else {
        $feedbackMessage = "Error: College ID is missing!";
        $messageType = "error";
    }
}

$colleges = [];
try {
    $stmt = $db->query("SELECT collid, collfullname, collshortname FROM colleges");
    $colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching colleges: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colleges</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        header {
            background-color: #013220;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 20px;
            background-color: #dc3545;
            border-radius: 5px;
        }

        header a:hover {
            background-color: #c82333;
        }

        .container {
            padding: 20px;
        }

        .feedback {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .feedback.success {
            background-color: #013220;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .feedback.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #013220;
            color: white;
        }

        tr:nth-child(even) {
            background-color: hsla(120, 100%, 25%, 0.3);
        }

        .add-form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .add-form input, .add-form button {
            padding: 10px;
            width: 230px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .add-form button {
            width: auto;
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        .add-form button:hover {
            background-color: #0056b3;
        }

        table a {
            color: #013220;
            text-decoration: none;
            font-weight: bold;
        }

        table a:hover {
            text-decoration: underline;
            color: #015f3e; 
        }
    </style>
    <script>
        function confirmDelete(collegeId) {
            if (confirm("Are you sure you want to delete this college?")) {
                var form = document.createElement("form");
                form.method = "POST";
                form.action = "";

                var collegeIdField = document.createElement("input");
                collegeIdField.type = "hidden";
                collegeIdField.name = "college_id";
                collegeIdField.value = collegeId;

                var actionField = document.createElement("input");
                actionField.type = "hidden";
                actionField.name = "action";
                actionField.value = "delete";

                form.appendChild(collegeIdField);
                form.appendChild(actionField);

                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</head>
<body>
    <header>
        <h1>Colleges</h1>
        <a href="mainPage.php">Back to Main Page</a>
    </header>
    <div class="container">
        <?php if (!empty($feedbackMessage)): ?>
            <div class="feedback <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($feedbackMessage); ?>
            </div>
        <?php endif; ?>

       
        <form method="POST" class="add-form">
            <input type="number" name="college_id" placeholder="Enter college ID" required>
            <input type="text" name="college_name" placeholder="Enter college name" required>
            <input type="text" name="short_name" placeholder="Short Name" required>
            <input type="hidden" name="action" value="add">
            <button type="submit">Add College</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>College Name</th>
                    <th>Short Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($colleges as $college): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($college['collid']); ?></td>
                        <td><?php echo htmlspecialchars($college['collfullname']); ?></td>
                        <td><?php echo htmlspecialchars($college['collshortname']); ?></td>
                        <td>
                            <a href="edit-college.php?id=<?php echo $college['collid']; ?>">Edit</a> | 
                            <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $college['collid']; ?>)">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
