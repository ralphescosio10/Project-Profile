<?php
session_start();


error_reporting(E_ALL);
ini_set('display_errors', 1);


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


$department = null;
$colleges = [];
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $deptid = intval($_GET['id']);

    try {
       
        $stmt = $db->prepare("SELECT * FROM departments WHERE deptid = :deptid");
        $stmt->bindParam(':deptid', $deptid, PDO::PARAM_INT);
        $stmt->execute();
        $department = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$department) {
            die("Department not found.");
        }

   
        $colleges = $db->query("SELECT collid, collfullname FROM colleges")->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error fetching data: " . $e->getMessage());
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $deptid = intval($_POST['deptid']);
    $deptfullname = trim($_POST['deptfullname']);
    $deptshortname = trim($_POST['deptshortname']);
    $deptcollid = intval($_POST['deptcollid']);

    try {
        $stmt = $db->prepare("UPDATE departments SET deptfullname = :deptfullname, deptshortname = :deptshortname, deptcollid = :deptcollid WHERE deptid = :deptid");
        $stmt->bindParam(':deptfullname', $deptfullname, PDO::PARAM_STR);
        $stmt->bindParam(':deptshortname', $deptshortname, PDO::PARAM_STR);
        $stmt->bindParam(':deptcollid', $deptcollid, PDO::PARAM_INT);
        $stmt->bindParam(':deptid', $deptid, PDO::PARAM_INT);

        $stmt->execute();

        
        if ($stmt->rowCount() > 0) {
            $feedback = [
                'success' => true,
                'message' => 'Department updated successfully!'
            ];
            header("Location: departments.php");
            exit(); 
        } else {
            $feedback = [
                'success' => false,
                'message' => 'No changes were made or department not found.'
            ];
        }
    } catch (PDOException $e) {
        $feedback = [
            'success' => false,
            'message' => 'Error updating department: ' . $e->getMessage()
        ];
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Department</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            margin-bottom: 20px;
            text-align: center;
            color: black;
        }

        label {
            font-weight: bold;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: grey;
        }

        .back-btn {
            display: inline-block;
            background-color: #013220;
            color: white;
            text-decoration: none;
            padding: 10px;
            text-align: center;
            margin-bottom: 10px;
            border-radius: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        .back-btn:hover {
            background-color:grey;
        }

        .feedback {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            display: <?php echo isset($feedback) ? 'block' : 'none'; ?>;
        }

        .feedback.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .feedback.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h2>Edit Department</h2>
        <a href="departments.php" class="back-btn">Back to Departments</a>

        <?php if (isset($feedback)): ?>
            <div class="feedback <?php echo $feedback['success'] ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($feedback['message']); ?>
            </div>
        <?php endif; ?>

        <input type="hidden" name="deptid" id="deptid" value="<?php echo htmlspecialchars($department['deptid']); ?>">

        <label for="deptfullname">Department Name:</label>
        <input type="text" id="deptfullname" name="deptfullname" value="<?php echo htmlspecialchars($department['deptfullname']); ?>" required>

        <label for="deptshortname">Short Name:</label>
        <input type="text" id="deptshortname" name="deptshortname" 
       value="<?php echo isset($department['deptshortname']) ? htmlspecialchars($department['deptshortname']) : ''; ?>">

        <label for="deptcollid">College:</label>
        <select id="deptcollid" name="deptcollid" required>
            <?php foreach ($colleges as $college): ?>
                <option value="<?php echo $college['collid']; ?>" <?php echo ($college['collid'] == $department['deptcollid']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($college['collfullname']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Update Department</button>
    </form>
</body>
</html>
