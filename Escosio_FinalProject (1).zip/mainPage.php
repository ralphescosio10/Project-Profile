<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('programimg.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            color: white;
        }

        header {
            background-color: #013220;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-size: 28px;
            color: white; 
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.6); 
        }

        header a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 12px 20px;
            background-color: #dc3545;
            border-radius: 5px;
          
        }

        header a:hover {
            background-color: #c82333;
            transform: scale(1.05);
        }

        .container {
            text-align: center;
            padding: 80px 40px;
            max-width: 1400px;
            margin: 40px auto;
            background-color: rgba(255, 255, 255, 0.4); 
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            color: white; 
            margin-bottom: 40px;
            font-size: 40px;
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.6); 
        }

        .container h3 {
            font-size: 30px;
            margin-bottom: 40px;
            color: white; 
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.6); 
        }

        .button-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 40px; 
            margin-top: 40px;
        }

        .button-container a {
            width: 300px;  
            height: 300px; 
            background-size: cover;
            background-position: center;
            color: white;
            font-size: 24px; 
            text-decoration: none;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, opacity 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .button-container a::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4); 
            z-index: 1;
            filter: blur(5px); 
        }

        .button-container a span {
            position: relative;
            z-index: 2;
            font-weight: bold;
            font-size: 24px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.6); 
        }

        .students {
            background-image: url('studentimg.png');
        }

        .colleges {
            background-image: url('collegeimg.jpg');
        }

        .programs {
            background-image: url('mainpagebg.jpg');
        }

        .departments {
            background-image: url('departmentimg.jpg');
        }

    
        .button-container a:hover {
            transform: scale(1.1);
            opacity: 0.85;
        }

        @media (max-width: 600px) {
            .button-container {
                flex-direction: column;
                align-items: center;
            }

            .button-container a {
                width: 80%;
                height: 250px;
                font-size: 18px; 
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>University Management Dashboard</h1>
        <a href="logout.php">Logout</a>
    </header>
    <div class="container">
        <h3>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h3>
        <h2>Please Select from the Box</h2>
        <div class="button-container">
            
            <a href="colleges.php" class="colleges">
                <span>Colleges</span>
            </a>
            <a href="departments.php" class="departments">
                <span>Departments</span>
            </a>
            <a href="programs.php" class="programs">
                <span>Programs</span>
            </a>
            <a href="students.php" class="students">
                <span>Students</span>
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
