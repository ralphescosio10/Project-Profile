<?php
session_start();


if (!isset($_SESSION['username'])) {
    echo json_encode(["success" => false, "message" => "Unauthorized access."]);
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]);
    exit();
}


$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['dept_name'], $data['college_id'])) {
    $deptId = isset($data['dept_id']) && is_numeric($data['dept_id']) ? intval($data['dept_id']) : null;
    $deptName = $data['dept_name'];
    $deptShortName = isset($data['dept_shortname']) ? $data['dept_shortname'] : null;
    $collegeId = intval($data['college_id']);

    try {
        $stmt = $db->prepare("INSERT INTO departments (deptid, deptfullname, deptshortname, deptcollid) VALUES (?, ?, ?, ?)");
        $stmt->execute([$deptId, $deptName, $deptShortName, $collegeId]);

        echo json_encode(["success" => true, "message" => "Department added successfully!"]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error adding department: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid input. Please provide all required fields."]);
}
