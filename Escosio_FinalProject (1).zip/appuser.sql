USE `usjr`;

CREATE TABLE IF NOT EXISTS `usjr`.`appusers` (
  `uid` INT NOT NULL AUTO_INCREMENT, 
  `name` VARCHAR(45) NOT NULL,     
  `password` VARCHAR(105) NOT NULL, 
  PRIMARY KEY (`uid`)               
);

select * from appusers;