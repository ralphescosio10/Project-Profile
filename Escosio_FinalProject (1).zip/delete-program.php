<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


if (isset($_GET['delete_id']) && !empty($_GET['delete_id'])) {
    $programId = intval($_GET['delete_id']); 

    try {
        
        $stmt = $db->prepare("DELETE FROM programs WHERE progid = :progid");
        $stmt->bindParam(':progid', $programId, PDO::PARAM_INT);

        if ($stmt->execute()) {
        
            echo json_encode(['success' => true, 'message' => 'Program deleted successfully!']);
        } else {
        
            echo json_encode(['success' => false, 'message' => 'Failed to delete program.']);
        }
    } catch (PDOException $e) {
       
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    
    echo json_encode(['success' => false, 'message' => 'Invalid program ID.']);
}
?>
