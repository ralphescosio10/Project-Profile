<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_colleges') {
    header("Content-Type: application/json");
    try {
        $colleges = $db->query("SELECT collid, collfullname FROM colleges")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['colleges' => $colleges]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Error fetching colleges: ' . $e->getMessage()]);
    }
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_programs') {
    header("Content-Type: application/json");
    $collegeId = $_GET['college_id'];
    try {
        $stmt = $db->prepare("SELECT progid, progfullname FROM programs WHERE progcollid = ?");
        $stmt->execute([$collegeId]);
        $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['programs' => $programs]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Error fetching programs: ' . $e->getMessage()]);
    }
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studid = $_POST['studid'];
    $studfirstname = $_POST['studfirstname'];
    $studlastname = $_POST['studlastname'];
    $studmidname = $_POST['studmidname'];
    $studprogid = $_POST['studprogid'];
    $studcollid = $_POST['studcollid'];
    $studyear = $_POST['studyear'];

    if (!$studid || !$studfirstname || !$studlastname || !$studprogid || !$studcollid || !$studyear) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit();
    }

    try {
      
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM students WHERE studid = ?");
        $checkStmt->execute([$studid]);
        $count = $checkStmt->fetchColumn();

        if ($count > 0) {
            echo json_encode(['success' => false, 'message' => 'Duplicate entry detected. Student ID already exists.']);
            exit();
        }

        
        $sql = "INSERT INTO students (studid, studfirstname, studlastname, studmidname, studprogid, studcollid, studyear)
                VALUES (:studid, :studfirstname, :studlastname, :studmidname, :studprogid, :studcollid, :studyear)";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'studid' => $studid,
            'studfirstname' => $studfirstname,
            'studlastname' => $studlastname,
            'studmidname' => $studmidname,
            'studprogid' => $studprogid,
            'studcollid' => $studcollid,
            'studyear' => $studyear
        ]);

        echo json_encode(['success' => true, 'message' => 'Student added successfully.']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error adding student: ' . $e->getMessage()]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin: 0 20px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input:focus, select:focus, button:focus {
            outline: 2px solid grey;
        }

        button {
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #005f17;
        }

        .notification-bar {
            display: none;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
        }

        .notification-bar.success {
            background-color: #013220;
            color: white;
        }

        .notification-bar.error {
            background-color: #dc3545;  
            color: white;
        }
    </style>
</head>
<body>
    <form id="addStudentForm">
        <div class="notification-bar" id="notification-bar"></div>
        <h2 style="">Add New Student</h2>
        <label for="studid">Student ID:</label>
        <input type="number" id="studid" name="studid" required>

        <label for="studfirstname" >First Name:</label>
        <input type="text" id="studfirstname" name="studfirstname" required>

        <label for="studlastname">Last Name:</label>
        <input type="text" id="studlastname" name="studlastname" required>

        <label for="studmidname">Middle Name:</label>
        <input type="text" id="studmidname" name="studmidname">

        <label for="studcollid" >College:</label>
        <select id="studcollid" name="studcollid" required>
            <option value="" disabled selected>-- Select College --</option>
        </select>

        <label for="studprogid" >Program:</label>
        <select id="studprogid" name="studprogid" required>
            <option value="" disabled selected>-- Select Program --</option>
        </select>

        <label for="studyear">Year:</label>
        <input type="number" id="studyear" name="studyear" min="1" max="5" required>

        <button type="submit">Add Student</button>
    </form>

    <script>
       
        axios.get('add-student.php?action=fetch_colleges')
            .then(response => {
                const collegeDropdown = document.getElementById('studcollid');
                response.data.colleges.forEach(college => {
                    const option = document.createElement('option');
                    option.value = college.collid;
                    option.textContent = college.collfullname;
                    collegeDropdown.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching colleges:', error));

       
        document.getElementById('studcollid').addEventListener('change', function () {
            const collegeId = this.value;
            if (collegeId) {
                axios.get(`add-student.php?action=fetch_programs&college_id=${collegeId}`)
                    .then(response => {
                        const programDropdown = document.getElementById('studprogid');
                        programDropdown.innerHTML = '<option value="" disabled selected>-- Select Program --</option>';
                        response.data.programs.forEach(program => {
                            const option = document.createElement('option');
                            option.value = program.progid;
                            option.textContent = program.progfullname;
                            programDropdown.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching programs:', error));
            }
        });

      
        document.getElementById('addStudentForm').addEventListener('submit', function (event) {
            event.preventDefault();

            const formData = new FormData(this);
            axios.post('add-student.php', formData)
                .then(response => {
                    if (response.data.success) {
            
                        const successMessage = encodeURIComponent(response.data.message);
                        window.location.href = `students.php?success=${successMessage}`;
                    } else {
                        showNotification(response.data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error adding student:', error);
                    showNotification('An error occurred while adding the student.', 'error');
                });
        });

        
        function showNotification(message, type) {
            const notificationBar = document.getElementById('notification-bar');
            notificationBar.textContent = message;
            notificationBar.className = `notification-bar ${type}`;
            notificationBar.style.display = 'block';
            setTimeout(() => {
                notificationBar.style.display = 'none';
            }, 3000);
        }
    </script>
</body>
</html>
