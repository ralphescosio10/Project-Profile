<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


$program = null;
$colleges = [];
$errorMessage = "";
$successMessage = "";


if (isset($_GET['id']) && !empty($_GET['id'])) {
    $programId = intval($_GET['id']);

    try {
        $stmt = $db->prepare("SELECT * FROM programs WHERE progid = :progid");
        $stmt->bindParam(':progid', $programId, PDO::PARAM_INT);
        $stmt->execute();
        $program = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$program) {
            $errorMessage = "Program not found.";
            exit();
        }

        
        $stmt = $db->query("SELECT collid, collfullname FROM colleges");
        $colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $errorMessage = "Error fetching program data: " . $e->getMessage();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $programName = $_POST['program_name'] ?? '';
    $collegeId = $_POST['college_id'] ?? '';
    $programId = $_POST['program_id'] ?? '';

    if (!empty($programName) && !empty($collegeId)) {
        try {
            $stmt = $db->prepare("UPDATE programs SET progfullname = :program_name, progcollid = :college_id WHERE progid = :program_id");
            $stmt->execute([
                'program_name' => $programName,
                'college_id' => $collegeId,
                'program_id' => $programId
            ]);

            echo json_encode(['success' => true, 'message' => 'Program updated successfully!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Error updating program: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Please fill in all fields.']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Program</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <form id="editProgramForm">
        <h2>Edit Program</h2>

        <?php if (!empty($successMessage)): ?>
            <div class="success"><?php echo htmlspecialchars($successMessage); ?></div>
        <?php endif; ?>

        <?php if (!empty($errorMessage)): ?>
            <div class="error"><?php echo htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <input type="hidden" name="program_id" value="<?php echo htmlspecialchars($program['progid']); ?>">

        <label for="program_name">Program Name:</label>
        <input type="text" id="program_name" name="program_name" value="<?php echo htmlspecialchars($program['progfullname']); ?>" required>

        <label for="college_id">College:</label>
        <select id="college_id" name="college_id" required>
            <option value="" disabled>-- Select College --</option>
            <?php foreach ($colleges as $college): ?>
                <option value="<?php echo $college['collid']; ?>" <?php echo ($college['collid'] == $program['progcollid']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($college['collfullname']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="button" onclick="updateProgram()">Update Program</button>
        <a href="programs.php" style="display:block;text-align:center;margin-top:10px;color:#013220;text-decoration:none;">Back to Programs</a>
    </form>

    <script>
      
        function updateProgram() {
            const formData = new FormData(document.getElementById('editProgramForm'));

            axios.post('edit-program.php', formData)
                .then(response => {
                    if (response.data.success) {
                        alert(response.data.message);
                        window.location.href = 'programs.php'; 
                    } else {
                        alert(response.data.message);
                    }
                })
                .catch(error => {
                    console.error("Error updating program:", error);
                    alert('Error updating program.');
                });
        }
    </script>
</body>
</html>
