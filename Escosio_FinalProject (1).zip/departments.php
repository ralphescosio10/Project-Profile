<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


$departments = [];
$college_id = isset($_GET['college_id']) ? $_GET['college_id'] : ''; 

try {
  
    if ($college_id) {
        $stmt = $db->prepare("SELECT departments.deptid, departments.deptfullname, departments.deptshortname, colleges.collfullname 
                              FROM departments 
                              INNER JOIN colleges ON departments.deptcollid = colleges.collid 
                              WHERE colleges.collid = ?");
        $stmt->execute([$college_id]);
    } else {
     
        $stmt = $db->query("SELECT departments.deptid, departments.deptfullname, departments.deptshortname, colleges.collfullname 
                            FROM departments 
                            INNER JOIN colleges ON departments.deptcollid = colleges.collid");
    }
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching departments: " . $e->getMessage());
}


$colleges = [];
try {
    $stmt = $db->query("SELECT collid, collfullname FROM colleges");
    $colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching colleges: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departments</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        header {
            background-color: 	#013220;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 20px;
            background-color: #dc3545;
            border-radius: 5px;
        }

        header a:hover {
            background-color: #c82333;
        }

        .container {
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.6);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .feedback {
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 10px;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            display: none;
            z-index: 1000;
        }

        .feedback.success {
            background-color: #28a745;
        }

        .feedback.error {
            background-color: #dc3545;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #013220;
            color: white;
        }

        tr:nth-child(even) {
            background-color:hsla(120,100%,25%,0.3);
        }

        .add-form, .filter-form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .add-form input, .add-form select, .filter-form select, .filter-form button {
            padding: 10px;
            width: 230px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .add-form button, .filter-form button {
            width: auto;
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        .add-form button:hover, .filter-form button:hover {
            background-color: #0056b3;
        }

        .filter-form button {
            background-color: #28a745;
        }

        .filter-form button:hover {
            background-color: #218838;
        }

        .edit-btn, .delete-btn {
            display: inline-block;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .edit-btn {
            background-color: #013220 ;
            color: white;
        }

        .edit-btn:hover {
            background-color: #45a049;
        }

        .delete-btn {
            background-color: #f44336;
            color: white;
        }

        .delete-btn:hover {
            background-color: #d32f2f;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 300px;
        }

        .modal-buttons {
            margin-top: 10px;
            display: flex;
            justify-content: space-evenly;
        }
    </style>
    <script>
       
        const axiosInstance = axios.create({
            baseURL: '',
            headers: {
                'Content-Type': 'application/json',
            },
        });

     
        function showFeedback(message, type) {
            const feedback = document.getElementById('feedbackPopup');
            feedback.textContent = message;
            feedback.className = `feedback ${type}`;
            feedback.style.display = 'block';

          
            setTimeout(() => {
                feedback.style.display = 'none';
            }, 3000);
        }

        async function addDepartment(event) {
            event.preventDefault(); 

            const formData = new FormData(event.target);
            const deptData = {
                dept_id: formData.get('dept_id') || null,
                dept_name: formData.get('dept_name'),
                dept_shortname: formData.get('dept_shortname') || null,
                college_id: formData.get('college_id'),
            };

            try {
                const response = await axiosInstance.post('add-department.php', deptData);

                if (response.data.success) {
                    showFeedback(response.data.message || 'Department added successfully!', 'success');
                    location.reload();
                } else {
                    showFeedback(response.data.message || 'Failed to add department.', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showFeedback('Error adding department: ' + (error.response?.data?.message || error.message), 'error');
            }
        }

        async function confirmDelete(departmentId) {
            try {
                const response = await axiosInstance.post('delete-department.php', { id: departmentId });

                if (response.data.success) {
                    showFeedback(response.data.message || 'Department deleted successfully!', 'success');
                    document.querySelector(`tr[data-id='${departmentId}']`).remove();
                } else {
                    showFeedback(response.data.message || 'Failed to delete department.', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showFeedback('Error deleting department: ' + (error.response?.data?.message || error.message), 'error');
            } finally {
                closeDeleteModal();
            }
        }

       
        function openDeleteModal(departmentId) {
            const modal = document.getElementById('deleteModal');
            modal.style.display = 'flex';
            const confirmBtn = document.getElementById('confirmDelete');
            confirmBtn.onclick = () => confirmDelete(departmentId);
        }

        function closeDeleteModal() {
            const modal = document.getElementById('deleteModal');
            modal.style.display = 'none';
        }

       
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelector('.add-form').addEventListener('submit', addDepartment);
        });
    </script>
</head>
<body>
    <header>
        <h1>Departments</h1>
        <a href="mainPage.php">Back to Main Page</a>
    </header>
    <div class="container">
      
        <div id="feedbackPopup" class="feedback"></div>

      
        <form method="GET" class="filter-form">
            <select name="college_id">
                <option value="">-- Select College --</option>
                <?php foreach ($colleges as $college): ?>
                    <option value="<?php echo $college['collid']; ?>" <?php echo ($college_id == $college['collid']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($college['collfullname']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Filter</button>
        </form>

      
        <form class="add-form">
            <input type="number" name="dept_id" placeholder="Enter department ID (optional)">
            <input type="text" name="dept_name" placeholder="Enter new department name" required>
            <input type="text" name="dept_shortname" placeholder="Enter department short name (optional)">
            <select name="college_id" required>
                <option value="" disabled selected>-- Select College --</option>
                <?php foreach ($colleges as $college): ?>
                    <option value="<?php echo $college['collid']; ?>">
                        <?php echo htmlspecialchars($college['collfullname']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Add Department</button>
        </form>

      
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Department Name</th>
                    <th>Short Name</th>
                    <th>College</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($departments as $department): ?>
                    <tr data-id="<?php echo htmlspecialchars($department['deptid']); ?>">
                        <td><?php echo htmlspecialchars($department['deptid']); ?></td>
                        <td><?php echo htmlspecialchars($department['deptfullname']); ?></td>
                        <td><?php echo htmlspecialchars($department['deptshortname'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($department['collfullname']); ?></td>
                        <td>
                            <a href="edit-department.php?id=<?php echo $department['deptid']; ?>" class="edit-btn">Edit</a>
                            <button onclick="openDeleteModal(<?php echo $department['deptid']; ?>)" class="delete-btn">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <p>Are you sure you want to delete this department?</p>
            <div class="modal-buttons">
                <button id="confirmDelete" class="confirm-btn">Yes</button>
                <button class="cancel-btn" onclick="closeDeleteModal()">No</button>
            </div>
        </div>
    </div>
</body>
</html>
