<?php

try {
    $dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
    $username = "root"; 
    $password = "root"; 

    $db = new PDO($dsn, $username, $password);

    
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    http_response_code(500); 
    echo json_encode(['message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

   
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    
    $usernameValue = trim($data['username'] ?? '');
    $passwordValue = trim($data['password'] ?? '');
    $confirmPassword = trim($data['confirm_password'] ?? '');

  
    if (empty($usernameValue) || empty($passwordValue) || empty($confirmPassword)) {
        http_response_code(400); 
        echo json_encode(['message' => 'All fields are required.']);
        exit();
    }

    if ($passwordValue !== $confirmPassword) {
        http_response_code(400); 
        echo json_encode(['message' => 'Passwords do not match.']);
        exit();
    }

    try {
       
        $checkSql = "SELECT COUNT(*) FROM appusers WHERE name = ?";
        $stmt = $db->prepare($checkSql);
        $stmt->execute([$usernameValue]);
        $userExists = $stmt->fetchColumn();

        if ($userExists) {
            http_response_code(409); 
            echo json_encode(['message' => 'Username is already taken. Please choose another.']);
        } else {
            
            $hashedPassword = password_hash($passwordValue, PASSWORD_BCRYPT);

            
            $sql = "INSERT INTO appusers (uid, name, password) VALUES (NULL, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->execute([$usernameValue, $hashedPassword]);

            echo json_encode(['message' => 'Registration successful!']);
        }
    } catch (PDOException $e) {
        http_response_code(500); 
        echo json_encode(['message' => 'Error: ' . $e->getMessage()]);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('registrationbg.jpg'); 
            background-size: cover;
            background-position: center;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            align-items: center;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input:focus {
            border-color: #007bff;
            outline: none;
        }

        button {
            padding: 12px 20px;
            background-color: grey;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clear-btn {
            background-color: #013220;
        }

        .clear-btn:hover {
            background-color: #e53935;
        }

        p {
            text-align: center;
            font-size: 14px;
        }

        .error,
        .success {
            font-size: 0.9em;
            text-align: center;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>
<body>
    <form id="registration-form">
        <h2>Register</h2>
        <div id="response-message"></div>

        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>

        <div class="buttons">
            <button type="submit">Register</button>
            <button type="reset" class="clear-btn">Clear</button>
        </div>
        <p>Already have an account? <a href="login.php">Log in here</a></p>
    </form>

    <script>
        document.getElementById('registration-form').addEventListener('submit', function(event) {
            event.preventDefault();

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;

            fetch('registration.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, confirm_password: confirmPassword }),
            })
                .then(response => response.json())
                .then(data => {
                    const messageContainer = document.getElementById('response-message');
                    if (data.message) {
                        messageContainer.innerHTML = `<div class="success">${data.message}</div>`;
                        document.getElementById('registration-form').reset();
                    } else {
                        messageContainer.innerHTML = `<div class="error">An error occurred.</div>`;
                    }
                })
                .catch(error => {
                    document.getElementById('response-message').innerHTML = `<div class="error">An error occurred: ${error}</div>`;
                });
        });
    </script>
</body>
</html>
