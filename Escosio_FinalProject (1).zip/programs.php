<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


$feedbackMessage = "";
$messageType = ""; 


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $programId = $_POST['program_id'] ?? ''; 
    $programName = trim($_POST['program_name'] ?? '');
    $shortName = trim($_POST['short_name'] ?? '');
    $collegeId = $_POST['college_id'] ?? '';
    $departmentId = $_POST['department_id'] ?? '';

    if (!empty($programId) && !empty($programName) && !empty($shortName) && !empty($collegeId) && !empty($departmentId)) {
        try {
          
            $stmt = $db->prepare("SELECT COUNT(*) FROM programs WHERE progfullname = :program_name AND progcollid = :college_id AND progcolldeptid = :department_id");
            $stmt->execute([
                'program_name' => $programName,
                'college_id' => $collegeId,
                'department_id' => $departmentId
            ]);
            $count = $stmt->fetchColumn();

            if ($count > 0) {
                $feedbackMessage = "Error: Program already exists in the selected college and department!";
                $messageType = "error";
            } else {
               
                $stmt = $db->prepare("INSERT INTO programs (progid, progfullname, progshortname, progcollid, progcolldeptid) 
                                      VALUES (:program_id, :program_name, :short_name, :college_id, :department_id)");
                $stmt->execute([
                    'program_id' => $programId,
                    'program_name' => $programName,
                    'short_name' => $shortName,
                    'college_id' => $collegeId,
                    'department_id' => $departmentId
                ]);
                $feedbackMessage = "Program added successfully!";
                $messageType = "success";
            }
        } catch (PDOException $e) {
            $feedbackMessage = "Error adding program: " . $e->getMessage();
            $messageType = "error";
        }
    } else {
        $feedbackMessage = "Error: All fields are required!";
        $messageType = "error";
    }
}


$programs = [];
$college_id = $_GET['college_id'] ?? '';
$department_id = $_GET['department_id'] ?? '';

try {
    $query = "SELECT programs.progid, programs.progfullname, programs.progshortname, colleges.collfullname, departments.deptfullname 
              FROM programs 
              INNER JOIN colleges ON programs.progcollid = colleges.collid 
              INNER JOIN departments ON programs.progcolldeptid = departments.deptid";

    $conditions = [];
    $params = [];

    if ($college_id) {
        $conditions[] = "colleges.collid = :college_id";
        $params['college_id'] = $college_id;
    }

    if ($department_id) {
        $conditions[] = "departments.deptid = :department_id";
        $params['department_id'] = $department_id;
    }

    if ($conditions) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching programs: " . $e->getMessage());
}


$colleges = [];
try {
    $stmt = $db->query("SELECT collid, collfullname FROM colleges");
    $colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching colleges: " . $e->getMessage());
}


if (isset($_GET['get_departments']) && isset($_GET['college_id'])) {
    $college_id = $_GET['college_id'];
    try {
        $stmt = $db->prepare("SELECT deptid, deptfullname FROM departments WHERE deptcollid = :college_id");
        $stmt->execute(['college_id' => $college_id]);
        $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($departments);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programs</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        header {
            background-color: #013220;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 20px;
            background-color: #dc3545;
            border-radius: 5px;
        }

        header a:hover {
            background-color: #c82333;
        }

        .container {
            padding: 20px;
        }

        .feedback {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .feedback.success {
            background-color: #013220;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .feedback.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #013220;
            color: white;
        }

        tr:nth-child(even) {
            background-color:hsla(120,100%,25%,0.3);
        }

        .add-form, .filter-form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .add-form input, .add-form select, .filter-form select, .filter-form button {
            padding: 10px;
            width: 230px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .add-form button, .filter-form button {
            width: auto;
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        .add-form button:hover, .filter-form button:hover {
            background-color: #0056b3;
        }

        .filter-form button {
            background-color: #013220;
        }

        .filter-form button:hover {
            background-color: #218838;
        }
        
        table a {
        color: #013220;
        text-decoration: none;
        font-weight: bold;
        }

        table a:hover {
        text-decoration: underline;
       color: #015f3e; 
        }


    </style>
    <script>
        
        function filterDepartments(collegeId) {
            const departmentDropdown = document.getElementById("filterDepartmentDropdown");
            departmentDropdown.innerHTML = `<option value="">-- Select Department --</option>`; 

            if (collegeId) {
                axios.get(`?get_departments=true&college_id=${collegeId}`)
                    .then(response => {
                        const departments = response.data;
                        departments.forEach(department => {
                            departmentDropdown.innerHTML += `<option value="${department.deptid}">${department.deptfullname}</option>`;
                        });
                    })
                    .catch(error => console.error("Error fetching departments:", error));
            }
        }

       
        function addProgramDepartment(collegeId) {
            const departmentDropdown = document.getElementById("departmentDropdown");
            departmentDropdown.innerHTML = `<option value="">-- Select Department --</option>`; 
            if (collegeId) {
                axios.get(`?get_departments=true&college_id=${collegeId}`)
                    .then(response => {
                        const departments = response.data;
                        departments.forEach(department => {
                            departmentDropdown.innerHTML += `<option value="${department.deptid}">${department.deptfullname}</option>`;
                        });
                    })
                    .catch(error => console.error("Error fetching departments:", error));
            }
        }

        
        function confirmDelete(progId) {
            const confirmation = confirm("Are you sure you want to delete this program?");
            if (confirmation) {
                axios.get(`delete-program.php?delete_id=${progId}`)
                    .then(response => {
                        if (response.data.success) {
                            alert("Program deleted successfully!");
                            window.location.reload();
                        } else {
                            alert("Error deleting program.");
                        }
                    })
                    .catch(error => console.error("Error deleting program:", error));
            }
        }
    </script>
</head>
<body>
    <header>
        <h1>Programs</h1>
        <a href="mainPage.php">Back to Main Page</a>
    </header>
    <div class="container">
        <?php if (!empty($feedbackMessage)): ?>
            <div class="feedback <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($feedbackMessage); ?>
            </div>
        <?php endif; ?>

        
        <form method="GET" class="filter-form">
            <select name="college_id" onchange="filterDepartments(this.value)">
                <option value="">-- Select College --</option>
                <?php foreach ($colleges as $college): ?>
                    <option value="<?php echo $college['collid']; ?>"><?php echo htmlspecialchars($college['collfullname']); ?></option>
                <?php endforeach; ?>
            </select>
            <select id="filterDepartmentDropdown" name="department_id">
                <option value="">-- Select Department --</option>
            </select>
            <button type="submit">Filter Programs</button>
        </form>

       
        <form method="POST" class="add-form">
            <input type="number" name="program_id" placeholder="Enter program ID" required>
            <input type="text" name="program_name" placeholder="Enter program name" required>
            <input type="text" name="short_name" placeholder="Short Name" required>
            <select name="college_id" onchange="addProgramDepartment(this.value)" required>
                <option value="">-- Select College --</option>
                <?php foreach ($colleges as $college): ?>
                    <option value="<?php echo $college['collid']; ?>"><?php echo htmlspecialchars($college['collfullname']); ?></option>
                <?php endforeach; ?>
            </select>
            <select id="departmentDropdown" name="department_id" required>
                <option value="">-- Select Department --</option>
            </select>
            <button type="submit">Add Program</button>
        </form>

    
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Program Name</th>
                    <th>Short Name</th>
                    <th>College</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($programs as $program): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($program['progid']); ?></td>
                        <td><?php echo htmlspecialchars($program['progfullname']); ?></td>
                        <td><?php echo htmlspecialchars($program['progshortname']); ?></td>
                        <td><?php echo htmlspecialchars($program['collfullname']); ?></td>
                        <td><?php echo htmlspecialchars($program['deptfullname']); ?></td>
                        <td>
                            <a href="edit-program.php?id=<?php echo $program['progid']; ?>">Edit</a> | 
                            <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $program['progid']; ?>)">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
