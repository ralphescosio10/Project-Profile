CREATE SCHEMA IF NOT EXISTS `usjr` DEFAULT CHARACTER SET utf8;

USE `usjr`;



DROP TABLE IF EXISTS `usjr`.`students`;
DROP TABLE IF EXISTS `usjr`.`programs`;
DROP TABLE IF EXISTS `usjr`.`departments`;
DROP TABLE IF EXISTS `usjr`.`colleges`;


CREATE TABLE `usjr`.`colleges` (
  `collid` INT NOT NULL,
  `collfullname` VARCHAR(100) NOT NULL,
  `collshortname` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`collid`)
);


CREATE TABLE `usjr`.`departments` (
  `deptid` INT NOT NULL,
  `deptfullname` VARCHAR(100) NOT NULL,
  `deptshortname` VARCHAR(20),
  `deptcollid` INT NOT NULL, 
  PRIMARY KEY (`deptid`),
  CONSTRAINT `fk_department_college_id`
     FOREIGN KEY (`deptcollid`) 
     REFERENCES `usjr`.`colleges` (`collid`)
     ON DELETE NO ACTION
     ON UPDATE NO ACTION
);


CREATE TABLE `usjr`.`programs` (
  `progid` INT NOT NULL,
  `progfullname` VARCHAR(100) NOT NULL,
  `progshortname` VARCHAR(20),
  `progcollid` INT NOT NULL,
  `progcolldeptid` INT NOT NULL,
  PRIMARY KEY (`progid`),
  CONSTRAINT `fk_program_college_id`
     FOREIGN KEY (`progcollid`)
     REFERENCES `usjr`.`colleges` (`collid`)
     ON DELETE NO ACTION
     ON UPDATE NO ACTION,
  CONSTRAINT `fk_program_college_department_id`
     FOREIGN KEY (`progcolldeptid`)
     REFERENCES `usjr`.`departments` (`deptid`)
     ON DELETE NO ACTION
     ON UPDATE NO ACTION
);


CREATE TABLE `usjr`.`students` (
  `studid` INT NOT NULL,
  `studfirstname` VARCHAR(50) NOT NULL,
  `studlastname` VARCHAR(50) NOT NULL,
  `studmidname` VARCHAR(50) NULL,
  `studprogid` INT NOT NULL,
  `studcollid` INT NOT NULL,
  `studyear` INT NOT NULL,
  PRIMARY KEY (`studid`),
  CONSTRAINT `fk_student_college_id`
     FOREIGN KEY (`studcollid`)
     REFERENCES `usjr`.`colleges` (`collid`)
     ON DELETE NO ACTION
     ON UPDATE NO ACTION
);


ALTER TABLE students
ADD CONSTRAINT fk_student_college_id
FOREIGN KEY (studcollid) REFERENCES colleges(collid)
ON DELETE CASCADE;

ALTER TABLE programs
DROP FOREIGN KEY fk_program_college_department_id;

ALTER TABLE programs
DROP FOREIGN KEY fk_program_college_department_id;

ALTER TABLE programs
ADD CONSTRAINT fk_program_college_department_id
FOREIGN KEY (progcolldeptid)
REFERENCES departments (deptid)
ON DELETE CASCADE
ON UPDATE NO ACTION;

ALTER TABLE departments
DROP FOREIGN KEY fk_department_college_id;

ALTER TABLE departments
DROP FOREIGN KEY fk_department_college_id;

ALTER TABLE departments
ADD CONSTRAINT fk_department_college_id
FOREIGN KEY (deptcollid)
REFERENCES colleges (collid)
ON DELETE CASCADE
ON UPDATE NO ACTION;

INSERT INTO `usjr`.`colleges` VALUES (1,'School of Business and Management','SBM');
INSERT INTO `usjr`.`colleges` VALUES (2,'School of Arts and Sciences','SAS');
INSERT INTO `usjr`.`colleges` VALUES (3,'School of Engineering','SoENG');
INSERT INTO `usjr`.`colleges` VALUES (4,'School of Education','SED');
INSERT INTO `usjr`.`colleges` VALUES (5,'School of Computer Studies','SCS');
INSERT INTO `usjr`.`colleges` VALUES (6,'School of Allied Medical Sciences','SAMS');

INSERT INTO `usjr`.`departments` VALUES(1001,'Accountancy and Finance Department',null,1);
INSERT INTO `usjr`.`departments` VALUES(1002,'Business and Entrepreneurship Department',null,1);
INSERT INTO `usjr`.`departments` VALUES(1003,'Marketing and Human Resource Management Department',null,1);
INSERT INTO `usjr`.`departments` VALUES(2001,'Department of Communications, Language and Literature','DLL',2);

INSERT INTO `usjr`.`programs` VALUES(1001,'Bachelor of Science in Accountancy','BSA',1,1001);
INSERT INTO `usjr`.`programs` VALUES(1002,'Bachelor of Science in Management Accounting','BSMA',1,1001);

SELECT * FROM usjr.departments;
