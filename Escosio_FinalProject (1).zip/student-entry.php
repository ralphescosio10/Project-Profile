<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_colleges') {
    header("Content-Type: application/json");
    try {
        $colleges = $db->query("SELECT collid, collfullname FROM colleges")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['colleges' => $colleges]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Error fetching colleges: ' . $e->getMessage()]);
    }
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_programs') {
    header("Content-Type: application/json");
    $collegeId = $_GET['college_id'];
    try {
        $stmt = $db->prepare("SELECT progid, progfullname FROM programs WHERE progcollid = ?");
        $stmt->execute([$collegeId]);
        $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['programs' => $programs]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Error fetching programs: ' . $e->getMessage()]);
    }
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studid = $_POST['studid'];
    $studfirstname = $_POST['studfirstname'];
    $studlastname = $_POST['studlastname'];
    $studmidname = $_POST['studmidname'];
    $studprogid = $_POST['studprogid'];
    $studcollid = $_POST['studcollid'];
    $studyear = $_POST['studyear'];

    if (!$studid || !$studfirstname || !$studlastname || !$studprogid || !$studcollid || !$studyear) {
        header("Location: students.php?status=error&message=All%20fields%20are%20required.");
        exit();
    }

    try {
        $sql = "INSERT INTO students (studid, studfirstname, studlastname, studmidname, studprogid, studcollid, studyear)
                VALUES (:studid, :studfirstname, :studlastname, :studmidname, :studprogid, :studcollid, :studyear)";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'studid' => $studid,
            'studfirstname' => $studfirstname,
            'studlastname' => $studlastname,
            'studmidname' => $studmidname,
            'studprogid' => $studprogid,
            'studcollid' => $studcollid,
            'studyear' => $studyear
        ]);

        header("Location: students.php?status=success&message=Student%20added%20successfully.");
        exit();
    } catch (PDOException $e) {
        header("Location: students.php?status=error&message=" . urlencode($e->getMessage()));
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const collegeDropdown = document.getElementById('studcollid');
            const programDropdown = document.getElementById('studprogid');

            
            fetch('student-entry.php?action=fetch_colleges')
                .then(response => response.json())
                .then(data => {
                    data.colleges.forEach(college => {
                        const option = document.createElement('option');
                        option.value = college.collid;
                        option.textContent = college.collfullname;
                        collegeDropdown.appendChild(option);
                    });
                });

          
            collegeDropdown.addEventListener('change', () => {
                const collegeId = collegeDropdown.value;
                fetch(`student-entry.php?action=fetch_programs&college_id=${collegeId}`)
                    .then(response => response.json())
                    .then(data => {
                        programDropdown.innerHTML = '<option value="" disabled selected>-- Select Program --</option>';
                        data.programs.forEach(program => {
                            const option = document.createElement('option');
                            option.value = program.progid;
                            option.textContent = program.progfullname;
                            programDropdown.appendChild(option);
                        });
                    });
            });
        });
    </script>
</head>
<body>
    <form method="POST" action="student-entry.php">
        <h2>Add New Student</h2>
        <label for="studid">Student ID:</label>
        <input type="number" id="studid" name="studid" required>

        <label for="studfirstname">First Name:</label>
        <input type="text" id="studfirstname" name="studfirstname" required>

        <label for="studlastname">Last Name:</label>
        <input type="text" id="studlastname" name="studlastname" required>

        <label for="studmidname">Middle Name:</label>
        <input type="text" id="studmidname" name="studmidname">

        <label for="studcollid">College:</label>
        <select id="studcollid" name="studcollid" required>
            <option value="" disabled selected>-- Select College --</option>
        </select>

        <label for="studprogid">Program:</label>
        <select id="studprogid" name="studprogid" required>
            <option value="" disabled selected>-- Select Program --</option>
        </select>

        <label for="studyear">Year:</label>
        <input type="number" id="studyear" name="studyear" min="1" max="5" required>

        <button type="submit">Add Student</button>
    </form>
</body>
</html>
