<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch students with college and program details
$query = "SELECT students.studid, students.studlastname, students.studfirstname, colleges.collfullname AS college, programs.progfullname AS program, students.studyear 
          FROM students 
          INNER JOIN colleges ON students.studcollid = colleges.collid
          INNER JOIN programs ON students.studprogid = programs.progid";

try {
    $stmt = $db->query($query);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching students: " . $e->getMessage());
}

// Get success message from query parameter
$successMessage = isset($_GET['success']) ? htmlspecialchars($_GET['success']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <script src="axios.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        header {
            background-color: #013220;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
        }

        header .nav-buttons {
            display: flex;
            gap: 10px;
        }

        header a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 20px;
            background-color: #dc3545;
            border-radius: 5px;
        }

        header a:hover {
            background-color: grey;
        }

        .container {
            padding: 20px;
        }

        h2 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #013220;
            color: white;
        }

        tr:nth-child(even) {
            background-color:hsla(120,100%,25%,0.3);
        }

        .actions button {
            padding: 5px 10px;
            margin-right: 5px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .edit-btn {
            background-color: #28a745;
            color: white;
        }

        .edit-btn:hover {
            background-color: #218838;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .add-student-btn {
    display: inline-block;
    background-color: #013220;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    font-size: 16px;
}

.add-student-btn:hover {
    background-color: #005f17; 
}
        

        .notification-bar {
            position: relative;
            margin: 0 auto;
            width: 90%;
            padding: 10px;
            text-align: center;
            font-size: 16px;
            border-radius: 5px;
            display: none;
        }

        .notification-bar.success {
            background-color: #28a745;
            color: white;
            display: block;
        }

        .notification-bar.error {
            background-color: #dc3545;
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .modal-content button {
            margin: 10px;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .modal-content .confirm-btn {
            background-color: #28a745;
            color: white;
        }

        .modal-content .cancel-btn {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome, <?= htmlspecialchars($_SESSION['username']); ?>!</h1>
        <div class="nav-buttons">
            <a href="mainPage.php">Back to Main Page</a>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <div class="container">
        
        <div class="notification-bar success" id="successNotification" style="display: <?= $successMessage ? 'block' : 'none'; ?>">
            <?= $successMessage; ?>
        </div>

        <h2>Student Management Dashboard</h2>
        <a href="add-student.php" class="add-student-btn">Add New Student</a>
        <h3>Student List</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>College</th>
                    <th>Program</th>
                    <th>Year</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                    <tr data-id="<?= $student['studid']; ?>">
                        <td><?= htmlspecialchars($student['studid']); ?></td>
                        <td><?= htmlspecialchars($student['studlastname']); ?></td>
                        <td><?= htmlspecialchars($student['studfirstname']); ?></td>
                        <td><?= htmlspecialchars($student['college']); ?></td>
                        <td><?= htmlspecialchars($student['program']); ?></td>
                        <td><?= htmlspecialchars($student['studyear']); ?></td>
                        <td class="actions">
                            <button class="edit-btn" onclick="location.href='edit-student.php?id=<?= $student['studid']; ?>'">Edit</button>
                            <button class="delete-btn" onclick="showDeleteModal(<?= $student['studid']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>


    <div class="modal" id="deleteModal">
        <div class="modal-content">
            <p>Are you sure you want to delete this student?</p>
            <button class="confirm-btn" id="confirmDeleteBtn">Yes</button>
            <button class="cancel-btn" onclick="closeModal()">No</button>
        </div>
    </div>

    <script>
        let studentToDelete = null;

        
        function showDeleteModal(studentId) {
            studentToDelete = studentId;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        
        function closeModal() {
            studentToDelete = null;
            document.getElementById('deleteModal').style.display = 'none';
        }

        
        document.getElementById('confirmDeleteBtn').addEventListener('click', function () {
            if (studentToDelete) {
                axios.delete('delete-student.php', { params: { id: studentToDelete } })
                    .then(response => {
                        if (response.data.success) {
                            showNotification(response.data.message || 'Student deleted successfully!', 'success');
                            document.querySelector(`tr[data-id="${studentToDelete}"]`).remove();
                        } else {
                            showNotification(response.data.message || 'Failed to delete the student.', 'error');
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        showNotification('Failed to delete the student.', 'error');
                    })
                    .finally(() => {
                        closeModal();
                    });
            }
        });

      
        function showNotification(message, type) {
            const notificationBar = document.getElementById('successNotification');
            notificationBar.innerText = message;
            notificationBar.className = `notification-bar ${type}`;
            notificationBar.style.display = 'block';
            setTimeout(() => {
                notificationBar.style.display = 'none';
            }, 5000); 
        }

        if (document.getElementById('successNotification').style.display === 'block') {
            setTimeout(() => {
                document.getElementById('successNotification').style.display = 'none';
            }, 5000);
        }
    </script>
</body>
</html>
