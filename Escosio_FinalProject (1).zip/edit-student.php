<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['college_id'])) {
    $collegeId = intval($_GET['college_id']);
    try {
        $stmt = $db->prepare("SELECT progid, progfullname FROM programs WHERE progcollid = :college_id");
        $stmt->bindParam(':college_id', $collegeId, PDO::PARAM_INT);
        $stmt->execute();
        $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($programs);
    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit();
}


$student = null;
$colleges = [];
$programs = [];
$errorMessage = "";
$successMessage = "";

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $studid = intval($_GET['id']);

    try {
     
        $stmt = $db->prepare("SELECT * FROM students WHERE studid = :studid");
        $stmt->bindParam(':studid', $studid, PDO::PARAM_INT);
        $stmt->execute();
        $student = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            $errorMessage = "Student not found.";
            exit();
        }

     
        $colleges = $db->query("SELECT collid, collfullname FROM colleges")->fetchAll(PDO::FETCH_ASSOC);

    
        $programsStmt = $db->prepare("SELECT progid, progfullname FROM programs WHERE progcollid = :collid");
        $programsStmt->bindParam(':collid', $student['studcollid'], PDO::PARAM_INT);
        $programsStmt->execute();
        $programs = $programsStmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $errorMessage = "Error fetching student data: " . $e->getMessage();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studid = $_POST['studid'] ?? '';
    $studfirstname = $_POST['studfirstname'] ?? '';
    $studlastname = $_POST['studlastname'] ?? '';
    $studmidname = $_POST['studmidname'] ?? '';
    $studprogid = $_POST['studprogid'] ?? null;
    $studcollid = $_POST['studcollid'] ?? null;
    $studyear = $_POST['studyear'] ?? '';

    if (empty($studprogid) || empty($studcollid)) {
        $errorMessage = "Please select both College and Program.";
    } else {
        try {
            $sql = "UPDATE students 
                    SET studfirstname = :studfirstname, 
                        studlastname = :studlastname, 
                        studmidname = :studmidname, 
                        studprogid = :studprogid, 
                        studcollid = :studcollid, 
                        studyear = :studyear 
                    WHERE studid = :studid";

            $stmt = $db->prepare($sql);
            $stmt->execute([
                'studfirstname' => $studfirstname,
                'studlastname' => $studlastname,
                'studmidname' => $studmidname,
                'studprogid' => $studprogid,
                'studcollid' => $studcollid,
                'studyear' => $studyear,
                'studid' => $studid
            ]);

            if ($stmt->rowCount() > 0) {
                header("Location: students.php?success=Student updated successfully!");
                exit();
            } else {
                $errorMessage = "No changes made or student ID not found.";
            }
        } catch (PDOException $e) {
            $errorMessage = "Error updating student: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            background-color: #013220;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color:hsla(120,100%,25%,0.3);
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const collegeDropdown = document.getElementById('studcollid');
            const programDropdown = document.getElementById('studprogid');

            collegeDropdown.addEventListener('change', function () {
                const collegeId = this.value;

                programDropdown.innerHTML = '<option value="">-- Select Program --</option>';

                if (collegeId) {
                    fetch(`edit-student.php?college_id=${collegeId}`)
                        .then(response => response.json())
                        .then(programs => {
                            programs.forEach(program => {
                                const option = document.createElement('option');
                                option.value = program.progid;
                                option.textContent = program.progfullname;
                                programDropdown.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Error fetching programs:', error));
                }
            });
        });
    </script>
</head>
<body>
    <form method="POST" action="edit-student.php?id=<?php echo $student['studid']; ?>">
        <h2>Edit Student</h2>

        <?php if (!empty($successMessage)): ?>
            <div class="success"><?php echo htmlspecialchars($successMessage); ?></div>
        <?php endif; ?>

        <?php if (!empty($errorMessage)): ?>
            <div class="error"><?php echo htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <input type="hidden" name="studid" value="<?php echo htmlspecialchars($student['studid']); ?>">

        <label for="studfirstname">First Name:</label>
        <input type="text" id="studfirstname" name="studfirstname" value="<?php echo htmlspecialchars($student['studfirstname']); ?>" required>

        <label for="studlastname">Last Name:</label>
        <input type="text" id="studlastname" name="studlastname" value="<?php echo htmlspecialchars($student['studlastname']); ?>" required>

        <label for="studmidname">Middle Name:</label>
        <input type="text" id="studmidname" name="studmidname" value="<?php echo htmlspecialchars($student['studmidname']); ?>">

        <label for="studcollid">College:</label>
        <select id="studcollid" name="studcollid" required>
            <option value="">-- Select College --</option>
            <?php foreach ($colleges as $college): ?>
                <option value="<?php echo $college['collid']; ?>" <?php echo ($college['collid'] == $student['studcollid']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($college['collfullname']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="studprogid">Program:</label>
        <select id="studprogid" name="studprogid" required>
            <option value="">-- Select Program --</option>
            <?php foreach ($programs as $program): ?>
                <option value="<?php echo $program['progid']; ?>" <?php echo ($program['progid'] == $student['studprogid']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($program['progfullname']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="studyear">Year:</label>
        <input type="number" id="studyear" name="studyear" value="<?php echo htmlspecialchars($student['studyear']); ?>" min="1" max="5" required>

        <button type="submit">Update Student</button>
    </form>
</body>
</html>
