<?php
session_start();


if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to continue.']);
    exit();
}


$dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
$username = "root";
$password = "root";

try {
    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}


if (isset($_GET['id']) && !empty($_GET['id'])) {
    $studid = intval($_GET['id']); 

    try {
        
        $stmt = $db->prepare("DELETE FROM students WHERE studid = :studid");
        $stmt->bindParam(':studid', $studid, PDO::PARAM_INT);

        if ($stmt->execute()) {
            
            echo json_encode(['success' => true, 'message' => 'Student deleted successfully.']);
        } else {
           
            echo json_encode(['success' => false, 'message' => 'Failed to delete student.']);
        }
    } catch (PDOException $e) {
    
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
   
    echo json_encode(['success' => false, 'message' => 'Invalid student ID.']);
}
?>
