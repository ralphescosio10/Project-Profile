<?php
session_start();

header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 

if (isset($_SESSION['username'])) {
    header("Location: students.php");
    exit();
}

try {
    $dsn = "mysql:host=localhost;dbname=usjr;charset=utf8";
    $username = "root"; 
    $password = "root"; 

    $db = new PDO($dsn, $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$errorMessage = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameValue = $_POST['username'] ?? '';
    $passwordValue = $_POST['password'] ?? '';

    try {
        $sql = "SELECT password FROM appusers WHERE name = ?";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(1, $usernameValue, PDO::PARAM_STR);
        $stmt->execute();

        $hashedPassword = $stmt->fetchColumn();

        if ($hashedPassword) {
            if (password_verify($passwordValue, $hashedPassword)) {
                $_SESSION['username'] = $usernameValue; 
                header("Location: mainPage.php");
                exit();
            } else {
                $errorMessage = "Invalid password.";
            }
        } else {
            $errorMessage = "Username does not exist.";
        }
    } catch (PDOException $e) {
        $errorMessage = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('student.jpg');
            background-color: #F7F1F1;
            background-size: cover;
            background-position: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .form-control {
            margin-bottom: 20px;
        }

        .btn-primary {
            width: 100%;
            padding: 12px 0;
            color: lightgreen;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 10px;
        }

        .register-link {
            text-align: center;
            margin-top: 15px;
            color: green;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Login Your Account</h2>

        <?php if (!empty($errorMessage)): ?>
            <div class="error"><?php echo htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
        </form>

        <div class="register-link">
            <p>Don't have an account? <a href="Registration.php">Register here</a></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
